import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class CampusSmartParking {
    interface Chargeable {
        double chargingFee(int kWh);
    }

    static abstract class Vehicle {
        private final String regNo;
        Vehicle(String regNo) {
            if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("Invalid registration");
            this.regNo = regNo;
        }
        public String getRegNo() { return regNo; }
        protected abstract double ratePerHour();
        public double calculateFee(long minutes) {
            if (minutes <= 0) return 0.0;
            long hours = (minutes + 59) / 60;
            return hours * ratePerHour();
        }
        @Override public boolean equals(Object o) {
            return o instanceof Vehicle && regNo.equals(((Vehicle)o).regNo);
        }
        @Override public int hashCode() { return regNo.hashCode(); }
        @Override public String toString() { return getClass().getSimpleName() + "[" + regNo + "]"; }
    }

    static class TwoWheeler extends Vehicle {
        TwoWheeler(String r) { super(r); }
        @Override protected double ratePerHour() { return 10.0; }
    }
    static class Car extends Vehicle {
        Car(String r) { super(r); }
        @Override protected double ratePerHour() { return 30.0; }
    }
    static class ElectricCar extends Vehicle implements Chargeable {
        ElectricCar(String r) { super(r); }
        @Override protected double ratePerHour() { return 40.0; }
        @Override public double chargingFee(int kWh) { return kWh * 9.0; }
    }
    static class EBike extends Vehicle {
        EBike(String r) { super(r); }
        @Override protected double ratePerHour() { return 0.0; }
        @Override public double calculateFee(long minutes) { return minutes <= 0 ? 0.0 : 20.0; }
    }
    static class DeliveryVan extends Vehicle {
        DeliveryVan(String r) { super(r); }
        @Override protected double ratePerHour() { return 30.0; }
        public double calculateFee(long minutes, LocalDateTime entry, LocalDateTime exit) {
            if (minutes <= 0) return 0.0;
            long hours = (minutes + 59) / 60;
            boolean overlapsBusinessHours =
                entry.toLocalDate().equals(exit.toLocalDate()) &&
                !exit.toLocalTime().isBefore(LocalTime.of(9, 0)) &&
                entry.toLocalTime().isBefore(LocalTime.of(17, 0));
            return hours * ratePerHour() * (overlapsBusinessHours ? 2.0 : 1.0);
        }
    }

    static class ParkingTicket {
        private static long nextTicket = 1000;
        private final long ticketNo;
        private final Vehicle vehicle;
        private final int floor;
        private final int slot;
        private final LocalDateTime entryTime;

        ParkingTicket(Vehicle vehicle, int floor, int slot, LocalDateTime entryTime) {
            this.ticketNo = nextTicket++;
            this.vehicle = Objects.requireNonNull(vehicle);
            this.floor = floor;
            this.slot = slot;
            this.entryTime = Objects.requireNonNull(entryTime);
        }
        public long getTicketNo() { return ticketNo; }
        public Vehicle getVehicle() { return vehicle; }
        public int getFloor() { return floor; }
        public int getSlot() { return slot; }
        public LocalDateTime getEntryTime() { return entryTime; }
    }

    static class ParkingFacility {
        private final String[][] slots;
        ParkingFacility(int[] slotsPerFloor) {
            slots = new String[slotsPerFloor.length][];
            for (int f = 0; f < slotsPerFloor.length; f++) {
                if (slotsPerFloor[f] < 0) throw new IllegalArgumentException("Negative capacity");
                slots[f] = new String[slotsPerFloor[f]];
            }
        }
        int[] allocate(String regNo) {
            for (int f = 0; f < slots.length; f++) {
                for (int s = 0; s < slots[f].length; s++) {
                    if (slots[f][s] == null) {
                        slots[f][s] = regNo;
                        return new int[]{f, s};
                    }
                }
            }
            return null;
        }
        boolean release(int floor, int slot) {
            if (floor < 0 || floor >= slots.length) return false;
            if (slot < 0 || slot >= slots[floor].length) return false;
            if (slots[floor][slot] == null) return false;
            slots[floor][slot] = null;
            return true;
        }
    }

    static class ParkingManager {
        private final ParkingFacility facility;
        private final Map<String, ParkingTicket> active = new HashMap<>();
        ParkingManager(ParkingFacility facility) { this.facility = facility; }

        ParkingTicket enter(Vehicle vehicle) {
            if (active.containsKey(vehicle.getRegNo()))
                throw new IllegalArgumentException("Duplicate active registration");
            int[] pos = facility.allocate(vehicle.getRegNo());
            if (pos == null) throw new IllegalStateException("Parking full");
            ParkingTicket ticket = new ParkingTicket(vehicle, pos[0], pos[1], LocalDateTime.now());
            active.put(vehicle.getRegNo(), ticket);
            return ticket;
        }

        double exit(String regNo, LocalDateTime exitTime, boolean validMonthlyPass,
                    boolean validVisitorDayPass, int chargingKWh) {
            ParkingTicket ticket = active.get(regNo);
            if (ticket == null) throw new IllegalArgumentException("No active ticket");
            long minutes = Math.max(0, Duration.between(ticket.getEntryTime(), exitTime).toMinutes());
            Vehicle v = ticket.getVehicle();
            double fee;
            if (validMonthlyPass || validVisitorDayPass) {
                fee = 0.0;
            } else if (v instanceof DeliveryVan van) {
                fee = van.calculateFee(minutes, ticket.getEntryTime(), exitTime);
            } else {
                fee = v.calculateFee(minutes);
            }
            if (v instanceof Chargeable c && !validMonthlyPass && !validVisitorDayPass)
                fee += c.chargingFee(chargingKWh);
            facility.release(ticket.getFloor(), ticket.getSlot());
            active.remove(regNo);
            return fee;
        }
    }

    public static void main(String[] args) {
        ParkingFacility facility = new ParkingFacility(new int[]{2, 3, 1, 4, 2});
        ParkingManager manager = new ParkingManager(facility);

        ParkingTicket t1 = manager.enter(new Car("TN02B2"));
        System.out.println("Ticket: " + t1.getTicketNo() + ", slot: "
                + t1.getFloor() + "-" + t1.getSlot());

        ParkingTicket t2 = manager.enter(new ElectricCar("TN03C3"));
        System.out.println("Ticket: " + t2.getTicketNo() + ", slot: "
                + t2.getFloor() + "-" + t2.getSlot());

        // Demonstration calculation independent of elapsed wall-clock time:
        Vehicle car = new Car("TN04D4");
        System.out.println("Car fee for 130 minutes: Rs. " + car.calculateFee(130));
        Vehicle bike = new EBike("TN05E5");
        System.out.println("E-bike flat fee: Rs. " + bike.calculateFee(75));
        DeliveryVan van = new DeliveryVan("TN06F6");
        LocalDate today = LocalDate.now();
        LocalDateTime in = today.atTime(10, 0);
        LocalDateTime out = today.atTime(12, 0);
        System.out.println("Delivery van fee in business hours: Rs. "
                + van.calculateFee(120, in, out));
        System.out.println("Invalid slot release: " + facility.release(99, 0));
    }
}
