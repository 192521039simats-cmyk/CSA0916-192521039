# Campus Smart-Parking System (Java)

## Source
- `CampusSmartParking.java` — complete Java source code for the campus smart-parking project.

## Requirements
- JDK 17 or later.

## Compile
```bash
javac CampusSmartParking.java
```

## Run
```bash
java CampusSmartParking
```

## Features included
- Multi-floor parking using a jagged array (different slot counts per floor).
- Vehicle hierarchy: two-wheeler, car, electric car, e-bike and delivery van.
- Unique parking ticket numbers.
- Active ticket lookup using a HashMap.
- Slot allocation and release validation.
- Started-hour fee calculation, e-bike flat fee, electric vehicle charging fee and delivery-van time-window pricing.
- Duplicate active registration validation.

The sample rates are illustrative and can be changed to match the rates specified by your instructor.
