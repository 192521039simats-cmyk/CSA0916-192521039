import java.util.*;

public class StudentSetDemo {
    static class BrokenStudent { String regNo,name; BrokenStudent(String r,String n){regNo=r;name=n;} public boolean equals(Object o){return o instanceof BrokenStudent s && regNo.equals(s.regNo);} }
    static final class Student { private final String regNo,name; Student(String r,String n){regNo=Objects.requireNonNull(r);name=Objects.requireNonNull(n);} public boolean equals(Object o){return o instanceof Student s && regNo.equals(s.regNo);} public int hashCode(){return Objects.hash(regNo);} public String toString(){return regNo+"-"+name;} }
    public static void main(String[] args){Set<BrokenStudent> broken=new HashSet<>();broken.add(new BrokenStudent("CSA01","Asha"));broken.add(new BrokenStudent("CSA01","Asha duplicate"));System.out.println("Broken class set size (may retain duplicates): "+broken.size());Set<Student> fixed=new HashSet<>();fixed.add(new Student("CSA01","Asha"));fixed.add(new Student("CSA01","Asha duplicate"));fixed.add(new Student("CSA02","Ravi"));System.out.println("Corrected class unique students: "+fixed.size());System.out.println("Set: "+fixed);System.out.println("Rule: equal objects must have equal hash codes; identity fields should be immutable while stored in a hash set.");}
}
