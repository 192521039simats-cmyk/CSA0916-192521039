import java.util.*;

public class StringsBenchmark {
    static volatile int sink;
    interface Builder { String build(int fields); }
    static String usingPlus(int n) { String s=""; for(int i=0;i<n;i++) s += "FIELD"+i+"="+i+";"; return s; }
    static String usingSB(int n) { StringBuilder b=new StringBuilder(); for(int i=0;i<n;i++) b.append("FIELD").append(i).append('=').append(i).append(';'); return b.toString(); }
    static String usingSBuf(int n) { StringBuffer b=new StringBuffer(); for(int i=0;i<n;i++) b.append("FIELD").append(i).append('=').append(i).append(';'); return b.toString(); }
    static long measure(Builder b,int fields,int reps) { long start=System.nanoTime(); for(int i=0;i<reps;i++) sink += b.build(fields).length(); return (System.nanoTime()-start)/reps; }
    public static void main(String[] args) {
        int[][] workloads={{6,100},{50,1000},{200,1000}};
        System.out.println("Q1 String construction benchmark | JDK "+System.getProperty("java.version"));
        System.out.println("fields,repetitions,plus_ns,sbuilder_ns,sbuffer_ns");
        for(int[] w:workloads){ int f=w[0],r=w[1]; for(int i=0;i<2;i++){usingPlus(f);usingSB(f);usingSBuf(f);} long p=0,s=0,b=0; for(int k=0;k<5;k++){p+=measure(StringsBenchmark::usingPlus,f,r);s+=measure(StringsBenchmark::usingSB,f,r);b+=measure(StringsBenchmark::usingSBuf,f,r);} System.out.printf(Locale.US,"%d,%d,%d,%d,%d%n",f,r,p/5,s/5,b/5); }
        System.out.println("Shared multithreaded log recommendation: StringBuffer for intrinsic synchronization, or a single-threaded StringBuilder behind a lock/queue.");
        System.out.println("Per-ticket text recommendation: StringBuilder (local and not shared).");
    }
}
