import java.util.*;

public class InventoryMapDemo {
    static class Medicine { final String code,name; int stock; Medicine(String c,String n,int s){code=c;name=n;stock=s;} public String toString(){return code+":"+name+"="+stock;} }
    public static void main(String[] args){Map<String,Medicine> hash=new HashMap<>(), tree=new TreeMap<>(), linked=new LinkedHashMap<>();String[][] rows={{"M30","Paracetamol","120"},{"M10","Amoxicillin","45"},{"M20","Cetirizine","80"}};for(String[]r:rows){Medicine m=new Medicine(r[0],r[1],Integer.parseInt(r[2]));hash.put(m.code,m);tree.put(m.code,m);linked.put(m.code,m);}System.out.println("HashMap lookup M20: "+hash.get("M20"));System.out.println("TreeMap code order: "+tree.values());System.out.println("LinkedHashMap insertion order: "+linked.values());System.out.println("Expected choice: HashMap for fast lookup + TreeMap/LinkedHashMap for required reports (or maintain both views).");}
}
