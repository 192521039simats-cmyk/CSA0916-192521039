import java.util.*;

public class Triage {
    static class Patient { final String name; final int severity; final long arrival; Patient(String n,int s,long a){name=n;severity=s;arrival=a;} public String toString(){return name+"(S"+severity+")";} }
    private long counter=0;
    private final PriorityQueue<Patient> queue=new PriorityQueue<>(Comparator.comparingInt((Patient p)->p.severity).thenComparingLong(p->p.arrival));
    void admit(String name,int severity){if(severity<1||severity>5)throw new IllegalArgumentException("Severity must be 1..5");queue.add(new Patient(name,severity,counter++));}
    Patient next(){return queue.poll();}
    public static void main(String[] args){Triage t=new Triage();t.admit("Asha",3);t.admit("Bala",1);t.admit("Chitra",2);t.admit("Deepak",1);t.admit("Esha",5);t.admit("Farhan",3);t.admit("Gita",2);t.admit("Hari",4);System.out.println("Treatment order (lower severity number first; FIFO on ties):");Patient p;while((p=t.next())!=null)System.out.println(p);System.out.println("Complexity: admit O(log n), poll O(log n), peek O(1), storage O(n).");}
}
