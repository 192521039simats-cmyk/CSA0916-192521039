import java.util.*;

public class UpNextRedesign {
    static volatile int sink;
    static long arrayListFrontRemoval(int n){ArrayList<Integer> a=new ArrayList<>();for(int i=0;i<n;i++)a.add(i);long t=System.nanoTime();while(!a.isEmpty())sink+=a.remove(0);return System.nanoTime()-t;}
    static long dequeFrontRemoval(int n){ArrayDeque<Integer> q=new ArrayDeque<>();for(int i=0;i<n;i++)q.addLast(i);long t=System.nanoTime();while(!q.isEmpty())sink+=q.removeFirst();return System.nanoTime()-t;}
    public static void main(String[] args){System.out.println("Q7 original ArrayList remove(0) vs redesigned ArrayDeque removeFirst (ns)");System.out.println("n,arraylist_ns,arraydeque_ns");for(int n:new int[]{2000,5000,10000,20000}){long a=0,d=0;for(int k=0;k<5;k++){a+=arrayListFrontRemoval(n);d+=dequeFrontRemoval(n);}System.out.printf(Locale.US,"%d,%d,%d%n",n,a/5,d/5);}System.out.println("Redesign: use ArrayDeque for frequent operations at both ends. ArrayList remains preferable for indexed access and random reads.");}
}
