import java.util.*;

public class PlaylistBenchmark {
    static volatile long sink;
    static long time(Runnable r){long t=System.nanoTime();r.run();return System.nanoTime()-t;}
    static long arrayListMiddle(int n){ArrayList<Integer> a=new ArrayList<>();for(int i=0;i<n;i++)a.add(i);return time(()->{for(int i=0;i<100;i++)a.add(a.size()/2,-1);});}
    static long linkedListMiddle(int n){LinkedList<Integer> a=new LinkedList<>();for(int i=0;i<n;i++)a.add(i);return time(()->{for(int i=0;i<100;i++)a.add(a.size()/2,-1);});}
    static long arrayListRandomAccess(int n){ArrayList<Integer>a=new ArrayList<>();for(int i=0;i<n;i++)a.add(i);return time(()->{for(int i=0;i<10000;i++)sink+=a.get((i*7919)%n);});}
    static long linkedListRandomAccess(int n){LinkedList<Integer>a=new LinkedList<>();for(int i=0;i<n;i++)a.add(i);return time(()->{for(int i=0;i<10000;i++)sink+=a.get((i*7919)%n);});}
    public static void main(String[] args){System.out.println("Q2 playlist experiment (ns; 100 middle inserts / 10,000 indexed reads)");System.out.println("n,array_middle,linked_middle,array_indexed,linked_indexed");for(int n:new int[]{1000,5000,10000}){long am=0,lm=0,ar=0,lr=0;for(int k=0;k<5;k++){am+=arrayListMiddle(n);lm+=linkedListMiddle(n);ar+=arrayListRandomAccess(n);lr+=linkedListRandomAccess(n);}System.out.printf(Locale.US,"%d,%d,%d,%d,%d%n",n,am/5,lm/5,ar/5,lr/5);}ArrayDeque<Integer> q=new ArrayDeque<>();q.addFirst(2);q.addLast(3);q.addFirst(1);System.out.println("Up Next ArrayDeque order: "+q+"; removeFirst="+q.removeFirst());}
}
