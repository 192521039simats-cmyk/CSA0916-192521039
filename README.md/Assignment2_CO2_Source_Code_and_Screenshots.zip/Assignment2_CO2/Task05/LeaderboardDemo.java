import java.util.*;

public class LeaderboardDemo {
    static class Team { final String name; final int points,goalDiff; Team(String n,int p,int g){name=n;points=p;goalDiff=g;} public String toString(){return name+"("+points+","+goalDiff+")";} }
    static class Leaderboard<T> { private final List<T> items=new ArrayList<>(); private final Comparator<? super T> order; Leaderboard(Comparator<? super T> c){order=c;} void add(T x){items.add(x);} List<T> ranking(){List<T> copy=new ArrayList<>(items);copy.sort(order);return copy;} void addAll(List<? extends T> source){items.addAll(source);} }
    public static void main(String[] args){Comparator<Team> order=Comparator.comparingInt((Team t)->t.points).reversed().thenComparing(Comparator.comparingInt((Team t)->t.goalDiff).reversed()).thenComparing(t->t.name);Leaderboard<Team> board=new Leaderboard<>(order);board.addAll(List.of(new Team("Falcons",20,8),new Team("Tigers",20,8),new Team("Eagles",18,10),new Team("Wolves",20,5)));System.out.println("Ranking (points desc, goal difference desc, name asc):");board.ranking().forEach(System.out::println);System.out.println("Original insertion list is not modified by ranking().");}
}
